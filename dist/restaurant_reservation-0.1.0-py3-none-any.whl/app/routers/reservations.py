from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session, select, and_
from app.db import get_session
from app.models import Reservation
from app.schemas.reservation import ReservationCreate
from typing import List
from datetime import timedelta

router = APIRouter()


@router.get("/", response_model=List[Reservation])
def get_reservations(session: Session = Depends(get_session)):
    return session.exec(select(Reservation)).all()


@router.post("/", response_model=Reservation)
def create_reservation(reservation: ReservationCreate,
                       session: Session = Depends(get_session)):
    # Проверка на конфликт по времени
    start_time = reservation.reservation_time
    end_time = start_time + timedelta(minutes=reservation.duration_minutes)

    conflicts = session.exec(
        select(Reservation).where(
            and_(
                Reservation.table_id == reservation.table_id,
                Reservation.reservation_time < end_time,
                (Reservation.reservation_time + timedelta(minutes=Reservation.duration_minutes)) > start_time
            )
        )
    ).all()

    if conflicts:
        raise HTTPException(status_code=400, detail="Table is already reserved at this time.")

    db_reservation = Reservation(**reservation.dict())
    session.add(db_reservation)
    session.commit()
    session.refresh(db_reservation)
    return db_reservation


@router.delete("/{reservation_id}")
def delete_reservation(reservation_id: int, session: Session = Depends(get_session)):
    reservation = session.get(Reservation, reservation_id)
    if not reservation:
        raise HTTPException(status_code=404, detail="Reservation not found")
    session.delete(reservation)
    session.commit()
    return {"ok": True}
