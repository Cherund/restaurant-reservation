from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session, select
from app.db import get_session
from app.models import Table
from app.schemas.table import TableCreate
from typing import List

router = APIRouter()


@router.get("/", response_model=List[Table])
def get_tables(session: Session = Depends(get_session)):
    return session.exec(select(Table)).all()


@router.post("/", response_model=Table)
def create_table(table: TableCreate, session: Session = Depends(get_session)):
    db_table = Table(**table.dict())
    session.add(db_table)
    session.commit()
    session.refresh(db_table)
    return db_table


@router.delete("/{table_id}")
def delete_table(table_id: int, session: Session = Depends(get_session)):
    table = session.get(Table, table_id)
    if not table:
        raise HTTPException(status_code=404, detail="Table not found")
    session.delete(table)
    session.commit()
    return {"ok": True}
