from fastapi import FastAPI
from app.db import engine
from app.models import Table, Reservation
from app.routers import tables, reservations

app = FastAPI(title="Restaurant Reservation API")

# Инициализация БД
@app.on_event("startup")
def on_startup():
    from sqlmodel import SQLModel
    SQLModel.metadata.create_all(engine)

app.include_router(tables.router, prefix="/tables", tags=["Tables"])
app.include_router(reservations.router, prefix="/reservations", tags=["Reservations"])
